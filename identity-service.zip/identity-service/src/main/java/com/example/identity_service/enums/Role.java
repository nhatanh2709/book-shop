package com.example.identity_service.enums;

public enum Role {
    USER,
    ADMIN,
    STAFF
}
